start util.exe tree.txt
